
#ifndef CHIPCONFIG_H
#define	CHIPCONFIG_H

#define FCY 60000000

void InitOscillator();

#endif	/* CHIPCONFIG_H */
