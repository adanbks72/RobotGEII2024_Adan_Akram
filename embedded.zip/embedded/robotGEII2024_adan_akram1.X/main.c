/* 
 * File:   main.c
 * Author: e 9
 *
 * Created on 11 septembre 2024, 14:06
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include "ChipConfig.h"
#include "IO.h"
#include "timer.h"
#include "PWM.h"
#include "ADC.h"
#include "Robot.h"
#include "main.h"
#include "UART.h"
#include "CB_TX1.h"
#include "CB_RX1.h"
#include "UART_Protocol.h"
#include <libpic30.h>
#include "QEI.h"
#include "Utilities.h"
#include "asservissement.h"
#include "GhostManager.h"

#include <string.h> 
unsigned char controlState;
int mode = 0;
double thetaRes = 0;
double thetawp = 0;
double thetaRobot = 0;
double thetaStop = 0;
double aAng = 0;
double vMax = 3;
double tolAng = 0;
double vAng = 0;

float vitessed = 25;
float vitesseg = 25;
unsigned char stateRobot;
unsigned int tstart = 0;
float Vitesse;
float boundaryTelemetre = 100;
unsigned char payload;

extern volatile GhostPosition ghostPosition;

int main(void) {

    InitOscillator();

    InitIO();
    InitTimer23();
    InitTimer1();
    InitPWM();
    InitADC1();
    InitTimer4();
    InitUART();
    InitQEI1();
    InitQEI2();
    
    //robotState.angleRadianFromOdometry = ghostPosition.theta;
    //robotState.xPosFromOdometry = ghostPosition.x;
    //robotState.yPosFromOdometry = ghostPosition.y;
    
    InitTrajectoryGenerator();
    
    robotState.angleRadianFromOdometry = ghostPosition.theta;
    robotState.xPosFromOdometry = ghostPosition.x;
    robotState.yPosFromOdometry = ghostPosition.y;
    
    SetupPidAsservissement(&robotState.PidX, 1.0f,  30.0f,0.0f, 100.0f, 100.0f, 100.0f);
    SetupPidAsservissement(&robotState.PidTheta, 1.0f,  30.0f,0.0f, 100.0f, 100.0f, 100.0f);
    SetupPidAsservissement(&robotState.PdTheta, 0.625f,  0.0f, 0.5f, 100.0f, 100.0f, 100.0f);
    SetupPidAsservissement(&robotState.PdLin, 0.0f,  0.0f, 0.5f, 100.0f, 100.0f, 100.0f);
    
            
    while (1) {
        if (CB_RX1_IsDataAvailable()) {
            unsigned char data = CB_RX1_Get();
            UartDecodeMessage(data);
        }
    }
    return 0;
}

unsigned char stateRobot;

void SetRobotState(unsigned char state) {
    robotState.mode = state;
}

/*void Cap() {
    if (robotState.distanceTelemetreExDroite < 24) {
        LED_VERTE_1 = 1;
    } else {
        LED_VERTE_1 = 0;
    }
    if (robotState.distanceTelemetreDroit < 30) {
        LED_ROUGE_1 = 1;
    } else {
        LED_ROUGE_1 = 0;
    }
    if (robotState.distanceTelemetreCentre < 38) {
        LED_ORANGE_1 = 1;
    } else {
        LED_ORANGE_1 = 0;
    }
    if (robotState.distanceTelemetreGauche < 30) {
        LED_BLEUE_1 = 1;
    } else {
        LED_BLEUE_1 = 0;
    }
    if (robotState.distanceTelemetreExGauche < 24) {
        LED_BLANCHE_1 = 1;
    } else {
        LED_BLANCHE_1 = 0;
    }
}*/

/*
unsigned char nextStateRobot = 0;

void SetNextRobotStateInAutomaticMode() {
    unsigned char positionObstacle = PAS_D_OBSTACLE;
    //�Dtermination de la position des obstacles en fonction des ���tlmtres
    if (robotState.distanceTelemetreDroit < 30 &&
            robotState.distanceTelemetreCentre > 20 &&
            robotState.distanceTelemetreGauche > 30) //Obstacle �droite
        positionObstacle = OBSTACLE_A_DROITE;
    else if (robotState.distanceTelemetreDroit > 30 &&
            robotState.distanceTelemetreCentre > 20 &&
            robotState.distanceTelemetreGauche < 30) //Obstacle �gauche
        positionObstacle = OBSTACLE_A_GAUCHE;
    else if (robotState.distanceTelemetreCentre < 20) //Obstacle en face
        positionObstacle = OBSTACLE_EN_FACE;
    else if (robotState.distanceTelemetreDroit > 30 &&
            robotState.distanceTelemetreCentre > 20 &&
            robotState.distanceTelemetreGauche > 30) //pas d?obstacle
        positionObstacle = PAS_D_OBSTACLE;

    if (robotState.distanceTelemetreExDroite < 20 &&
            robotState.distanceTelemetreDroit < 25 &&
            robotState.distanceTelemetreCentre > 20 && robotState.distanceTelemetreGauche > 30 &&
            robotState.distanceTelemetreExGauche > 30)
        positionObstacle = OBSTACLE_TRES_A_DROITE;
    else if (robotState.distanceTelemetreExDroite > 30 &&
            robotState.distanceTelemetreDroit > 30 &&
            robotState.distanceTelemetreCentre > 20 && robotState.distanceTelemetreGauche < 25 &&
            robotState.distanceTelemetreExGauche < 20)
        positionObstacle = OBSTACLE_TRES_A_GAUCHE;
   
    if (positionObstacle == PAS_D_OBSTACLE)
        nextStateRobot = STATE_AVANCE;
    else if (positionObstacle == OBSTACLE_A_DROITE)
        nextStateRobot = STATE_TOURNE_GAUCHE;
    else if (positionObstacle == OBSTACLE_A_GAUCHE)
        nextStateRobot = STATE_TOURNE_DROITE;
    else if (positionObstacle == OBSTACLE_EN_FACE)
        nextStateRobot = STATE_TOURNE_SUR_PLACE_GAUCHE;

    if (nextStateRobot != stateRobot - 1)
        stateRobot = nextStateRobot;
}

unsigned char ConversionBin() {
    unsigned char state = 0;
    if (robotState.distanceTelemetreExGauche < 23) state |= (1 << 4);
    if (robotState.distanceTelemetreGauche < 28) state |= (1 << 3);
    if (robotState.distanceTelemetreCentre < 37) state |= (1 << 2);
    if (robotState.distanceTelemetreDroit < 28) state |= (1 << 1);
    if (robotState.distanceTelemetreExDroite < 23) state |= (1 << 0);
    return state;
}

void OperatingSystemLoop(void) {
    if (tstop <= 59000 && tstart) {
        unsigned char stateRobot = ConversionBin();

        switch (stateRobot) {
            case 0b00000: // Aucun /
                stateRobot = STATE_AVANCE;
                break;

            case 0b00001: // extr�me droite/
                stateRobot = STATE_TOURNE_GAUCHE;
                break;

            case 0b00010: // droite/
                stateRobot = STATE_TOURNE_GAUCHE;
                break;

            case 0b00011: // droite et extr�me droite/
                stateRobot = STATE_TOURNE_GAUCHE;
                break;

            case 0b00100: // centre/
            case 0b00101: // centre et extr�me droite
            case 0b00111: // droite, centre et extr�me droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_GAUCHE;
                break;

            case 0b01000: // gauche/////
                stateRobot = STATE_TOURNE_DROITE;
                break;

            case 0b01001: // gauche et extr�me droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_GAUCHE;
                break;

            case 0b01010: // gauche et droite///
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b01011: // gauche, droite et extr�me droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_GAUCHE;
                break;

            case 0b01100: // gauche et centre//
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b01101: // gauche, centre et extr�me droite//////
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b01110: // gauche, centre et droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b10000: // extr�me gauche//
                stateRobot = STATE_TOURNE_DROITE;
                break;

            case 0b01111: // gauche, droite, centre, et extr�me droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_GAUCHE;
                break;

            case 0b10001: // extr�me gauche et extr�me droite//
                stateRobot = STATE_AVANCE;
                break;

            case 0b10010: // extr�me gauche et droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b10011: // extr�me gauche, droite et extr�me droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b10100: // extr�me gauche et centre// 
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b10101: // extr�me gauche, centre et extr�me droite////
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b10110: // extr�me gauche, centre et droite
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b10111: // extr�me gauche, droite, centre, et extr�me droite
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b11000: // gauche et extr�me gauche//
                stateRobot = STATE_TOURNE_DROITE;
                break;

            case 0b11001: // gauche, extr�me gauche et extr�me droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b11010: // gauche, extr�me gauche et droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b11011: // gauche, droite, extr�me gauche et extr�me droite//
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b11100: // gauche, centre et extr�me gauche
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b11101: // gauche, centre, extr�me gauche et extr�me droite
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b11110: // extr�me gauche, gauche, centre, et droite
                stateRobot = STATE_TOURNE_SUR_PLACE_DROITE;
                break;

            case 0b11111: // partout
                stateRobot = STATE_RECULE;
                break;

            default:
                stateRobot = STATE_TOURNE_SUR_PLACE_GAUCHE;
                break;
        }
        switch (stateRobot) {

            case STATE_AVANCE:
                VitesseDroit();
                VitesseExtremeDroit();
                VitesseGauche();
                VitesseExtremeGauche();
                PWMSetSpeedConsigne(Vitesse, MOTEUR_DROIT);
                PWMSetSpeedConsigne(Vitesse, MOTEUR_GAUCHE);
                break;

            case STATE_TOURNE_GAUCHE:
                VitesseDroit();
                PWMSetSpeedConsigne(14, MOTEUR_DROIT);
                PWMSetSpeedConsigne(0, MOTEUR_GAUCHE);
                LED_BLANCHE_2 = 0;
                LED_BLEUE_2 = 0;
                LED_ORANGE_2 = 0;
                LED_ROUGE_2 = 0;
                LED_VERTE_2 = 0;
                break;


            case STATE_TOURNE_DROITE:
                VitesseGauche();
                PWMSetSpeedConsigne(0, MOTEUR_DROIT);
                PWMSetSpeedConsigne(14, MOTEUR_GAUCHE);
                LED_BLANCHE_2 = 0;
                LED_BLEUE_2 = 0;
                LED_ORANGE_2 = 0;
                LED_ROUGE_2 = 0;
                LED_VERTE_2 = 0;
                break;

            case STATE_TOURNE_SUR_PLACE_GAUCHE:
                VitesseDroit();
                VitesseGauche();
                PWMSetSpeedConsigne(12, MOTEUR_DROIT);
                PWMSetSpeedConsigne(-12, MOTEUR_GAUCHE);
                LED_BLANCHE_2 = 0;
                LED_BLEUE_2 = 0;
                LED_ORANGE_2 = 0;
                LED_ROUGE_2 = 0;
                LED_VERTE_2 = 0;
                break;

            case STATE_TOURNE_SUR_PLACE_DROITE:
                VitesseDroit();
                VitesseGauche();
                PWMSetSpeedConsigne(-12, MOTEUR_DROIT);
                PWMSetSpeedConsigne(12, MOTEUR_GAUCHE);
                LED_BLANCHE_2 = 0;
                LED_BLEUE_2 = 0;
                LED_ORANGE_2 = 0;
                LED_ROUGE_2 = 0;
                LED_VERTE_2 = 0;
                break;

            case STATE_RECULE:
                PWMSetSpeedConsigne(-17, MOTEUR_DROIT);
                PWMSetSpeedConsigne(-17, MOTEUR_GAUCHE);
                LED_BLANCHE_2 = 0;
                LED_BLEUE_2 = 0;
                LED_ORANGE_2 = 0;
                LED_ROUGE_2 = 0;
                LED_VERTE_2 = 0;
                break;

            case STATE_RECULE_GAUCHE:
                PWMSetSpeedConsigne(-12, MOTEUR_DROIT);
                PWMSetSpeedConsigne(-7, MOTEUR_GAUCHE);
                LED_BLANCHE_2 = 0;
                LED_BLEUE_2 = 0;
                LED_ORANGE_2 = 0;
                LED_ROUGE_2 = 0;
                LED_VERTE_2 = 0;
                break;

            case STATE_DEMI_TOUR:
                PWMSetSpeedConsigne(-15, MOTEUR_DROIT);
                PWMSetSpeedConsigne(-15, MOTEUR_GAUCHE);
                LED_BLANCHE_2 = 0;
                LED_BLEUE_2 = 0;
                LED_ORANGE_2 = 0;
                LED_ROUGE_2 = 0;
                LED_VERTE_2 = 0;
                break;

            case STATE_ATTENTE:
                PWMSetSpeedConsigne(0, MOTEUR_DROIT);
                PWMSetSpeedConsigne(0, MOTEUR_GAUCHE);
                LED_BLANCHE_2 = 0;
                LED_BLEUE_2 = 0;
                LED_ORANGE_2 = 0;
                LED_ROUGE_2 = 0;
                LED_VERTE_2 = 0;
                break;

            default:
                break;
        }
    } else {
        tstart = 0;
        PWMSetSpeedConsigne(0, MOTEUR_DROIT);
        PWMSetSpeedConsigne(0, MOTEUR_GAUCHE);
    }
}

void VitesseCentre() {
    float V_BASSE = 30;
    float V_HAUTE = 50;

    if (robotState.distanceTelemetreCentre < V_BASSE) {
        Vitesse = 9;
    } else if (robotState.distanceTelemetreCentre < V_HAUTE) {
        Vitesse = 15 + (robotState.distanceTelemetreCentre - 30) * (10 / 20);
    } else {
        Vitesse = 24;
    }
}

void VitesseExtremeGauche() {
    float V_BASSE = 20;
    float V_HAUTE = 35;

    if (robotState.distanceTelemetreExGauche < V_BASSE) {
        Vitesse = 9;
    } else if (robotState.distanceTelemetreExGauche < V_HAUTE) {
        Vitesse = 9 + (robotState.distanceTelemetreExGauche - 18) * (10 / 15);
    } else {
        Vitesse = 24;
    }
}

void VitesseDroit() {
    float V_BASSE = 20;
    float V_HAUTE = 50;

    if (robotState.distanceTelemetreDroit < V_BASSE) {
        Vitesse = 8;
    } else if (robotState.distanceTelemetreDroit < V_HAUTE) {
        Vitesse = 9 + (robotState.distanceTelemetreDroit - 20) * (15 / 30);
    } else {
        Vitesse = 24;
    }
}

void VitesseExtremeDroit() {
    float V_BASSE = 20;
    float V_HAUTE = 35;

    if (robotState.distanceTelemetreExDroite < V_BASSE) {
        Vitesse = 9;
    } else if (robotState.distanceTelemetreExDroite < V_HAUTE) {
        Vitesse = 9 + (robotState.distanceTelemetreExDroite - 20) * (10 / 15);
    } else {
        Vitesse = 24;
    }
}

void VitesseGauche() {
    float V_BASSE = 20;
    float V_HAUTE = 50;

    if (robotState.distanceTelemetreGauche < V_BASSE) {
        Vitesse = 8;
    } else if (robotState.distanceTelemetreGauche < V_HAUTE) {
        Vitesse = 9 + (robotState.distanceTelemetreGauche - 20) * (15 / 30);
    } else {
        Vitesse = 24;
    }
}*/