#include "Robot.h"
#include "main.h"

volatile ROBOT_STATE_BITS robotState;