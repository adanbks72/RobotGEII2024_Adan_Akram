/* 
 * File:   robotState.h
 * Author: E306-PC4
 *
 * Created on 12 septembre 2025, 08:50
 */

#ifndef ROBOTSTATE_H
#define	ROBOTSTATE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ROBOTSTATE_H */

